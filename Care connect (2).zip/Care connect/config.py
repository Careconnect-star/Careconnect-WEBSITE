import os
from datetime import timedelta

class Config:
    # Basic Flask config
    SECRET_KEY = os.environ.get('SECRET_KEY') or 'your-secret-key'
    
    # Database config
    SQLALCHEMY_DATABASE_URI = os.environ.get('DATABASE_URL') or 'sqlite:///database.db'
    SQLALCHEMY_TRACK_MODIFICATIONS = False
    
    # File upload config
    UPLOAD_FOLDER = os.path.join(os.path.dirname(os.path.abspath(__file__)), 'uploads')
    MAX_CONTENT_LENGTH = 16 * 1024 * 1024  # 16MB max file size
    ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png'}
    
    # Mail config
    MAIL_SERVER = 'smtp.gmail.com'
    MAIL_PORT = 587
    MAIL_USE_TLS = True
    MAIL_USERNAME = os.environ.get('MAIL_USERNAME') or 'your-email@gmail.com'  # Replace with your Gmail address
    MAIL_PASSWORD = os.environ.get('MAIL_PASSWORD') or 'your-app-password'  # Replace with your Gmail App Password
    MAIL_DEFAULT_SENDER = os.environ.get('MAIL_USERNAME') or 'your-email@gmail.com'
    
    # Session config
    PERMANENT_SESSION_LIFETIME = timedelta(days=7)
    
    # Insurance config
    INSURANCE_PLANS = {
        'basic': {
            'name': 'Basic Plan',
            'base_price': 5000,
            'coverage': 'Basic medical coverage',
            'features': ['Inpatient care', 'Outpatient care', 'Emergency services']
        },
        'standard': {
            'name': 'Standard Plan',
            'base_price': 10000,
            'coverage': 'Comprehensive medical coverage',
            'features': ['Inpatient care', 'Outpatient care', 'Emergency services', 'Specialist consultations']
        },
        'premium': {
            'name': 'Premium Plan',
            'base_price': 15000,
            'coverage': 'Premium medical coverage',
            'features': ['Inpatient care', 'Outpatient care', 'Emergency services', 'Specialist consultations', 'Dental care']
        }
    }
    
    # Waiting period config
    WAITING_PERIOD_DAYS = 240  # 8 months
    
    # Family discount config
    FAMILY_DISCOUNT_RATE = 0.08  # 8% per additional member
    MAX_FAMILY_DISCOUNT = 0.32   # Maximum 32% discount 