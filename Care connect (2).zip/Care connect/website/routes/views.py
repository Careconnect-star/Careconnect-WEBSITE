from flask import Blueprint, render_template, request, flash, redirect, url_for, session, current_app, jsonify
from flask_login import login_required, current_user
from ..models import User, TempPlan, Claim, PlanRenewal, ChatMessage
from .. import db
from datetime import datetime, timedelta
from werkzeug.utils import secure_filename
import os
from ..utils import calculator, validator, recommender, formatter
from flask_mail import Message
from .. import mail

views = Blueprint('views', __name__)

@views.route('/', methods=['GET', 'POST'])
def home():
    return render_template("home.html", user=current_user)

@views.route('/individual-health-insurance', methods=['GET', 'POST'])
@login_required
def individual_health():
    if request.method == 'POST':
        selected_plan = request.form.get('plan')
        
        if not selected_plan:
            flash('Please select a plan', category='error')
            return redirect(url_for('views.individual_health'))
            
        try:
            user = User.query.get(current_user.id)
            if not user:
                flash('User not found', category='error')
                return redirect(url_for('views.home'))
            
            # Set default premium based on plan type
            premium_map = {
                'bronze': 799,
                'silver': 1499,
                'gold': 2499,
                'diamond': 3999
            }
            premium = premium_map.get(selected_plan, 799)  # Default to bronze price if plan not found
            
            # Update user's plan
            user.plan = selected_plan
            db.session.commit()
            
            # Create or update TempPlan
            temp_plan = TempPlan.query.filter_by(user_id=current_user.id).first()
            if not temp_plan:
                temp_plan = TempPlan(
                    user_id=current_user.id,
                    plan_type=selected_plan,
                    selection_date=datetime.utcnow(),
                    waiting_period_end=datetime.utcnow() + timedelta(days=240)
                )
                db.session.add(temp_plan)
            else:
                temp_plan.plan_type = selected_plan
                temp_plan.selection_date = datetime.utcnow()
                temp_plan.waiting_period_end = datetime.utcnow() + timedelta(days=240)
                temp_plan.plan_status = 'waiting'
                temp_plan.health_checkup_status = 'pending'
                temp_plan.health_checkup_file = None
            
            db.session.commit()
            flash('Plan selected successfully!', category='success')
            return redirect(url_for('views.payment', plan=selected_plan, premium=premium))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while saving your plan selection', category='error')
            return redirect(url_for('views.individual_health'))
            
    return render_template("individual-health-insurance.html", user=current_user)

@views.route('/family-health-insurance', methods=['GET', 'POST'])
@login_required
def family_health():
    if request.method == 'POST':
        selected_plan = request.form.get('plan')
        family_members = request.form.getlist('family_members')
        
        if not selected_plan:
            flash('Please select a plan', category='error')
            return redirect(url_for('views.family_health'))
            
        try:
            user = User.query.get(current_user.id)
            if not user:
                flash('User not found', category='error')
                return redirect(url_for('views.home'))
            
            # Set default premium based on family plan type
            premium_map = {
                'bronze-family': 1499,
                'silver-family': 2499,
                'gold-family': 3999,
                'diamond-family': 5999
            }
            premium = premium_map.get(selected_plan, 1499)  # Default to bronze family price if plan not found
            
            # Calculate family discount based on number of members
            num_members = len(family_members)
            if num_members >= 2:
                discount = 10  # 10% discount for 2+ members
            if num_members >= 4:
                discount = 15  # 15% discount for 4+ members
            if num_members >= 6:
                discount = 20  # 20% discount for 6+ members
            else:
                discount = 0
                
            # Apply discount
            premium = premium * (1 - discount/100)
            
            # Update user's plan
            user.plan = selected_plan
            user.family_members = ','.join(family_members) if family_members else None
            db.session.commit()
            
            # Create or update TempPlan
            temp_plan = TempPlan.query.filter_by(user_id=current_user.id).first()
            if not temp_plan:
                temp_plan = TempPlan(
                    user_id=current_user.id,
                    plan_type=selected_plan,
                    selection_date=datetime.utcnow(),
                    waiting_period_end=datetime.utcnow() + timedelta(days=240),
                    plan_status='waiting'
                )
                db.session.add(temp_plan)
            else:
                temp_plan.plan_type = selected_plan
                temp_plan.selection_date = datetime.utcnow()
                temp_plan.waiting_period_end = datetime.utcnow() + timedelta(days=240)
                temp_plan.plan_status = 'waiting'
                temp_plan.health_checkup_status = 'pending'
                temp_plan.health_checkup_file = None
            
            db.session.commit()
            flash('Family plan selected successfully!', category='success')
            return redirect(url_for('views.payment', plan=selected_plan, premium=premium, discount=discount))
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while saving your plan selection', category='error')
            return redirect(url_for('views.family_health'))
            
    return render_template("Family Health Insurance.html", user=current_user)

@views.route('/select-family-members', methods=['POST'])
@login_required
def select_family_members():
    if request.method == 'POST':
        selected_members = request.form.getlist('family_members')
        session['selected_family_members'] = selected_members
        return redirect(url_for('views.family_health'))

@views.route('/payment', methods=['GET', 'POST'])
@login_required
def payment():
    plan = request.args.get('plan')
    premium = request.args.get('premium', type=float)
    discount = request.args.get('discount', 0, type=int)
    
    if not plan or premium is None:
        flash('Invalid plan selection', category='error')
        return redirect(url_for('views.home'))
    
    # Calculate final amount with discount
    final_amount = premium - (premium * discount / 100)
    
    if request.method == 'POST':
        try:
            # Process payment here (this is a placeholder)
            # In a real application, you would integrate with a payment gateway
            
            # Update user's payment status
            user = User.query.get(current_user.id)
            user.payment_status = 'completed'
            user.payment_date = datetime.utcnow()
            
            # Update TempPlan status
            temp_plan = TempPlan.query.filter_by(user_id=current_user.id).first()
            if temp_plan:
                # Don't set plan_status to active immediately
                # Keep it in waiting status until waiting period is over
                temp_plan.plan_status = 'waiting'
                # Set waiting period end date to 8 months from now
                temp_plan.waiting_period_end = datetime.utcnow() + timedelta(days=240)
            
            db.session.commit()
            flash('Payment successful! Your plan is now in waiting period. Please complete the health checkup after the 8-month waiting period.', category='success')
            return redirect(url_for('views.my_health_plan'))
        except Exception as e:
            db.session.rollback()
            flash('Payment failed. Please try again.', category='error')
            return redirect(url_for('views.payment', plan=plan, premium=premium, discount=discount))
            
    return render_template("payment.html", 
                         user=current_user,
                         plan=plan,
                         premium=premium,
                         discount=discount,
                         final_amount=final_amount)

@views.route('/live-chat-support', methods=['GET'])
def live_chat_support():
    return render_template("LiveChatSupport.html", user=current_user, now=datetime.now())

@views.route('/call-support', methods=['GET'])
def call_support():
    return render_template("call_support.html", user=current_user)

@views.route('/my-health-plan', methods=['GET'])
@login_required
def my_health_plan():
    # Get the user's current plan from User model
    user = User.query.get(current_user.id)
    temp_plan = TempPlan.query.filter_by(user_id=current_user.id).first()
    
    if not temp_plan and user.plan:
        # Create a new TempPlan from user's existing plan
        temp_plan = TempPlan(
            user_id=current_user.id,
            plan_type=user.plan,
            selection_date=datetime.utcnow(),
            waiting_period_end=datetime.utcnow() + timedelta(days=30),
            plan_status='waiting'  # Start in waiting status
        )
        db.session.add(temp_plan)
        db.session.commit()
    
    if temp_plan:
        # Calculate days remaining in waiting period
        now = datetime.utcnow()
        days_remaining = (temp_plan.waiting_period_end - now).days if temp_plan.waiting_period_end > now else 0
        progress = min(100, max(0, (240 - days_remaining) / 240 * 100))
        
        # Format dates for display
        selection_date = temp_plan.selection_date.strftime('%B %d, %Y')
        waiting_period_end = temp_plan.waiting_period_end.strftime('%B %d, %Y')
        
        # Get status message
        if temp_plan.plan_status == 'active':
            status_message = "Your plan is active and coverage is in effect."
        elif temp_plan.plan_status == 'waiting':
            status_message = f"Your plan is in the 8-month waiting period. {days_remaining} days remaining."
        else:
            status_message = "Please complete your plan activation."
        
        return render_template('Check my Health Careplan.html',
                             user=current_user,
                             temp_plan=temp_plan,
                             selection_date=selection_date,
                             waiting_period_end=waiting_period_end,
                             progress=progress,
                             status_message=status_message)
    else:
        flash("You haven't selected a health plan yet.", category='info')
        return redirect(url_for('views.individual_health'))

@views.route('/upload-health-checkup', methods=['POST'])
@login_required
def upload_health_checkup():
    if 'health_checkup_file' not in request.files:
        flash('No file uploaded', 'error')
        return redirect(url_for('views.my_health_plan'))
    
    file = request.files['health_checkup_file']
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('views.my_health_plan'))
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], filename)
        file.save(file_path)
        
        temp_plan = TempPlan.query.filter_by(user_id=current_user.id).first()
        if temp_plan and temp_plan.is_waiting_period_over():
            temp_plan.health_checkup_file = file_path
            temp_plan.plan_status = 'submitted'
            db.session.commit()
            flash('Health checkup report uploaded successfully. Our team will review it shortly.', 'success')
        else:
            flash('You are not eligible to upload a health checkup report at this time.', 'error')
    else:
        flash('Invalid file type. Please upload a PDF or image file.', 'error')
    
    return redirect(url_for('views.my_health_plan'))

def allowed_file(filename):
    ALLOWED_EXTENSIONS = {'pdf', 'jpg', 'jpeg', 'png'}
    return '.' in filename and filename.rsplit('.', 1)[1].lower() in ALLOWED_EXTENSIONS

@views.route('/claims', methods=['GET'])
@login_required
def claims():
    user_claims = Claim.query.filter_by(user_id=current_user.id).order_by(Claim.submission_date.desc()).all()
    formatted_claims = [formatter.format_claim_data(claim.__dict__) for claim in user_claims]
    return render_template('claims.html', claims=formatted_claims, user=current_user)

@views.route('/submit-claim', methods=['GET', 'POST'])
@login_required
def submit_claim():
    if request.method == 'POST':
        try:
            # Get form data
            claim_type = request.form.get('claim_type')
            amount = request.form.get('amount')
            date = request.form.get('date_of_service')
            description = request.form.get('description')
            
            # Validate required fields
            if not all([claim_type, amount, date]):
                flash('Please fill in all required fields', category='error')
                return redirect(url_for('views.submit_claim'))
            
            # Convert amount to float and validate
            try:
                amount = float(amount)
                if amount <= 0:
                    flash('Amount must be greater than 0', category='error')
                    return redirect(url_for('views.submit_claim'))
            except ValueError:
                flash('Invalid amount format', category='error')
                return redirect(url_for('views.submit_claim'))
            
            new_claim = Claim(
                user_id=current_user.id,
                claim_type=claim_type,
                amount=amount,  # Now guaranteed to be float
                description=description,
                date_of_service=datetime.strptime(date, '%Y-%m-%d').date()
            )
            
            # Handle document upload
            if 'documents' in request.files:
                file = request.files['documents']
                if file and file.filename != '' and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], 'claims', filename)
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                    file.save(file_path)
                    new_claim.documents = file_path
            
            db.session.add(new_claim)
            db.session.commit()
            flash('Claim submitted successfully!', category='success')
            return redirect(url_for('views.claims'))
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while submitting your claim', category='error')
            return redirect(url_for('views.submit_claim'))
            
    return render_template('submit_claim.html', user=current_user)

@views.route('/claim/<int:claim_id>', methods=['GET'])
@login_required
def view_claim(claim_id):
    claim = Claim.query.get_or_404(claim_id)
    
    # Ensure user can only view their own claims
    if claim.user_id != current_user.id:
        flash('Unauthorized access', category='error')
        return redirect(url_for('views.claims'))
    
    formatted_claim = formatter.format_claim_data(claim.__dict__)
    return render_template('view_claim.html', claim=formatted_claim, user=current_user)

@views.route('/renew-plan', methods=['GET', 'POST'])
@login_required
def renew_plan():
    if request.method == 'POST':
        new_plan = request.form.get('new_plan')
        renewal_date = request.form.get('renewal_date')
        
        if not new_plan or not renewal_date:
            flash('Please select a plan and renewal date', category='error')
            return redirect(url_for('views.renew_plan'))
            
        try:
            # Get current user and plan
            user = User.query.get(current_user.id)
            current_plan = user.plan
            
            # Validate plan type based on current plan
            valid_individual_plans = ['bronze', 'silver', 'gold', 'diamond']
            valid_family_plans = ['bronze-family', 'silver-family', 'gold-family', 'diamond-family']
            
            is_family_plan = 'family' in current_plan if current_plan else False
            valid_plans = valid_family_plans if is_family_plan else valid_individual_plans
            
            if new_plan not in valid_plans:
                flash(f'Invalid plan selected. Please choose from: {", ".join(valid_plans)}', category='error')
                return redirect(url_for('views.renew_plan'))
            
            renewal = PlanRenewal(
                user_id=current_user.id,
                current_plan=current_plan,
                new_plan=new_plan,
                renewal_date=datetime.strptime(renewal_date, '%Y-%m-%d'),
                status='pending'
            )
            
            # Handle health checkup upload
            if 'health_checkup_file' in request.files:
                file = request.files['health_checkup_file']
                if file and file.filename != '' and allowed_file(file.filename):
                    filename = secure_filename(file.filename)
                    file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], 'renewals', filename)
                    os.makedirs(os.path.dirname(file_path), exist_ok=True)
                    file.save(file_path)
                    renewal.health_checkup_file = file_path
                    renewal.health_checkup_status = 'submitted'
            
            db.session.add(renewal)
            db.session.commit()
            flash('Plan renewal request submitted successfully!', category='success')
            return redirect(url_for('views.renewal_status'))
            
        except Exception as e:
            db.session.rollback()
            flash('An error occurred while submitting your renewal request', category='error')
            return redirect(url_for('views.renew_plan'))
    
    # For GET request, determine available plans based on current plan
    user = User.query.get(current_user.id)
    current_plan = user.plan
    is_family_plan = 'family' in current_plan if current_plan else False
    
    available_plans = [
        {'id': 'bronze-family', 'name': 'Bronze Family', 'price': '₹1,499'},
        {'id': 'silver-family', 'name': 'Silver Family', 'price': '₹2,499'},
        {'id': 'gold-family', 'name': 'Gold Family', 'price': '₹3,999'},
        {'id': 'diamond-family', 'name': 'Diamond Family', 'price': '₹5,999'}
    ] if is_family_plan else [
        {'id': 'bronze', 'name': 'Bronze', 'price': '₹799'},
        {'id': 'silver', 'name': 'Silver', 'price': '₹1,499'},
        {'id': 'gold', 'name': 'Gold', 'price': '₹2,499'},
        {'id': 'diamond', 'name': 'Diamond', 'price': '₹3,999'}
    ]
    
    return render_template('renew_plan.html', 
                         user=current_user,
                         current_plan=current_plan,
                         available_plans=available_plans)

@views.route('/renewal-status', methods=['GET'])
@login_required
def renewal_status():
    renewal = PlanRenewal.query.filter_by(user_id=current_user.id).order_by(PlanRenewal.submission_date.desc()).first()
    return render_template('renewal_status.html', renewal=renewal, user=current_user)

@views.route('/upload-renewal-health-checkup', methods=['POST'])
@login_required
def upload_renewal_health_checkup():
    if 'health_checkup_file' not in request.files:
        flash('No file uploaded', 'error')
        return redirect(url_for('views.renewal_status'))
    
    file = request.files['health_checkup_file']
    if file.filename == '':
        flash('No file selected', 'error')
        return redirect(url_for('views.renewal_status'))
    
    if file and allowed_file(file.filename):
        filename = secure_filename(file.filename)
        file_path = os.path.join(current_app.config['UPLOAD_FOLDER'], 'renewals', filename)
        os.makedirs(os.path.dirname(file_path), exist_ok=True)
        file.save(file_path)
        
        renewal = PlanRenewal.query.filter_by(user_id=current_user.id).order_by(PlanRenewal.submission_date.desc()).first()
        if renewal:
            renewal.health_checkup_file = file_path
            renewal.health_checkup_status = 'submitted'
            db.session.commit()
            flash('Health checkup report uploaded successfully. Our team will review it shortly.', 'success')
        else:
            flash('No renewal request found.', 'error')
    else:
        flash('Invalid file type. Please upload a PDF or image file.', 'error')
    
    return redirect(url_for('views.renewal_status'))

@views.route('/offline-claim', methods=['GET'])
@login_required
def offline_claim():
    return render_template('offline_claim.html', user=current_user)

@views.route('/email', methods=['GET', 'POST'])
def email():
    if request.method == 'POST':
        name = request.form.get('name')
        email = request.form.get('email')
        subject = request.form.get('subject')
        message = request.form.get('message')
        policy_number = request.form.get('policy_number')
        
        try:
            # Create email message
            msg = Message(
                subject=f"Contact Form: {subject}",
                sender=email,
                recipients=[current_app.config['MAIL_USERNAME']],  # Send to admin email
                body=f"""
                From: {name} <{email}>
                Policy Number: {policy_number or 'Not provided'}
                
                Message:
                {message}
                """
            )
            
            # Send email
            mail.send(msg)
            flash('Your message has been sent successfully! We will get back to you soon.', category='success')
        except Exception as e:
            current_app.logger.error(f"Failed to send email: {str(e)}")
            flash('Sorry, there was an error sending your message. Please try again later.', category='error')
            
        return redirect(url_for('views.email'))
        
    return render_template("email.html", user=current_user)

@views.route('/api/chatbot/message', methods=['POST'])
def chatbot_message():
    """Handle chatbot messages"""
    data = request.get_json()
    message = data.get('message', '')
    
    if not message:
        return jsonify({'error': 'No message provided'}), 400
        
    # Get user data for personalized responses
    user_data = {
        'age': current_user.age if current_user.is_authenticated else 0,
        'family_size': len(current_user.family_members.split(',')) if current_user.is_authenticated and current_user.family_members else 1,
        'medical_history': []  # Add medical history if available
    }
    
    # Get personalized response
    response = recommender.get_recommendation(user_data)
    return jsonify(response)

@views.route('/api/chatbot/calculate-premium', methods=['POST'])
def calculate_premium():
    """Calculate insurance premium"""
    data = request.get_json()
    age = data.get('age')
    plan_type = data.get('plan_type')
    family_members = data.get('family_members')
    
    if not all([age, plan_type]):
        return jsonify({'error': 'Missing required parameters'}), 400
        
    premium = calculator.calculate_premium(age, plan_type, family_members)
    return jsonify({'premium': premium})

@views.route('/api/chatbot/validate-claim', methods=['POST'])
def validate_claim():
    """Validate claim data"""
    data = request.get_json()
    result = validator.validate_claim_data(data)
    return jsonify(result)

@views.route('/api/chatbot/recommend-plan', methods=['POST'])
def recommend_plan():
    """Get personalized plan recommendation"""
    data = request.get_json()
    recommendation = recommender.get_recommendation(data)
    return jsonify(recommendation)

@views.route('/api/chat/send', methods=['POST'])
@login_required
def send_chat_message():
    data = request.get_json()
    message = data.get('message')
    session_id = data.get('session_id')
    is_agent = data.get('is_agent', False)
    
    if not message:
        return jsonify({'error': 'No message provided'}), 400
    
    try:
        # Create a new chat session if none exists
        if not session_id:
            session_id = f"chat_{datetime.utcnow().strftime('%Y%m%d%H%M%S')}_{current_user.id}"
        
        # Create the chat message
        chat_message = ChatMessage(
            sender_id=current_user.id,
            content=message,
            chat_session=session_id
        )
        
        # If sender is customer and there's no receiver, assign to available agent
        if not is_agent:
            available_agent = User.query.filter_by(role='agent').first()
            if available_agent:
                chat_message.receiver_id = available_agent.id
        
        db.session.add(chat_message)
        db.session.commit()
        
        return jsonify({
            'success': True,
            'session_id': session_id,
            'message': message
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500

@views.route('/api/chat/messages', methods=['GET'])
@login_required
def get_chat_messages():
    session_id = request.args.get('session_id')
    is_agent = request.args.get('is_agent', 'false').lower() == 'true'
    
    if not session_id:
        return jsonify({'error': 'No session ID provided'}), 400
    
    try:
        # Get unread messages for the current user
        if is_agent:
            messages = ChatMessage.query.filter(
                ChatMessage.chat_session == session_id,
                ChatMessage.receiver_id == current_user.id,
                ChatMessage.is_read == False
            ).all()
        else:
            messages = ChatMessage.query.filter(
                ChatMessage.chat_session == session_id,
                ChatMessage.sender_id != current_user.id,
                ChatMessage.is_read == False
            ).all()
        
        # Mark messages as read
        for message in messages:
            message.is_read = True
        db.session.commit()
        
        return jsonify({
            'messages': [{
                'content': msg.content,
                'sender_id': msg.sender_id,
                'timestamp': msg.timestamp.strftime('%Y-%m-%d %H:%M:%S')
            } for msg in messages]
        })
        
    except Exception as e:
        db.session.rollback()
        return jsonify({'error': str(e)}), 500 