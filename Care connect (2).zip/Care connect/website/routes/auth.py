from flask import Blueprint, render_template, request, flash, redirect, url_for
from flask_login import login_user, login_required, logout_user, current_user
from ..models import User
from werkzeug.security import generate_password_hash, check_password_hash
from website import db
import random
import string

auth = Blueprint('auth', __name__)

def create_initial_agents():
    """Create initial agent accounts if they don't exist"""
    agents = [
        {'email': 'agent1@careconnect.com', 'password': 'Agent123!', 'name': 'Agent Smith'},
        {'email': 'agent2@careconnect.com', 'password': 'Agent123!', 'name': 'Agent Johnson'},
        {'email': 'agent3@careconnect.com', 'password': 'Agent123!', 'name': 'Agent Brown'},
        {'email': 'agent4@careconnect.com', 'password': 'Agent123!', 'name': 'Agent Davis'}
    ]
    
    for agent_data in agents:
        agent = User.query.filter_by(email=agent_data['email']).first()
        if not agent:
            pid = User.generate_pid()
            new_agent = User(
                email=agent_data['email'],
                first_name=agent_data['name'],
                password=generate_password_hash(agent_data['password']),
                pid=pid,
                role='agent'
            )
            db.session.add(new_agent)
    
    try:
        db.session.commit()
    except Exception as e:
        db.session.rollback()

def generate_temp_password(length=10):
    """Generate a random temporary password"""
    characters = string.ascii_letters + string.digits + "!@#$%^&*"
    return ''.join(random.choice(characters) for _ in range(length))

@auth.route('/login', methods=['GET', 'POST'])
def login():
    if request.method == 'POST':
        email = request.form.get('email')
        password = request.form.get('password')
        remember = True if request.form.get('remember') else False

        user = User.query.filter_by(email=email).first()

        if not user or not check_password_hash(user.password, password):
            flash('Please check your login details and try again.', category='error')
            return redirect(url_for('auth.login'))

        login_user(user, remember=remember)
        if user.needs_password_change:
            flash('Please change your temporary password.', category='warning')
            return redirect(url_for('auth.change_password'))
            
        # Redirect agents to the live chat support page
        if user.role == 'agent':
            return redirect(url_for('views.live_chat_support'))
        return redirect(url_for('views.home'))

    return render_template("login.html")

@auth.route('/forgot-password', methods=['GET', 'POST'])
def forgot_password():
    if request.method == 'POST':
        email = request.form.get('email')
        user = User.query.filter_by(email=email).first()
        
        if user:
            # Generate a temporary password
            temp_password = generate_temp_password()
            
            # Update user's password and set flag to change it on next login
            user.password = generate_password_hash(temp_password)
            user.needs_password_change = True
            db.session.commit()
            
            # In a production environment, you would send this via email
            flash(f'Your temporary password is: {temp_password}\nPlease change it after logging in.', category='success')
            return redirect(url_for('auth.login'))
        else:
            flash('No account found with that email address.', category='error')
    
    return render_template("forgot_password.html")

@auth.route('/change-password', methods=['GET', 'POST'])
@login_required
def change_password():
    if request.method == 'POST':
        current_password = request.form.get('current_password')
        new_password = request.form.get('new_password')
        confirm_password = request.form.get('confirm_password')
        
        if not check_password_hash(current_user.password, current_password):
            flash('Current password is incorrect.', category='error')
        elif new_password != confirm_password:
            flash('New passwords don\'t match.', category='error')
        elif len(new_password) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            current_user.password = generate_password_hash(new_password)
            current_user.needs_password_change = False
            db.session.commit()
            flash('Password updated successfully!', category='success')
            return redirect(url_for('views.home'))
            
    return render_template("change_password.html")

@auth.route('/logout')
@login_required
def logout():
    logout_user()
    return redirect(url_for('views.home'))

@auth.route('/sign-up', methods=['GET', 'POST'])
def sign_up():
    if request.method == 'POST':
        email = request.form.get('email')
        first_name = request.form.get('firstName')
        password1 = request.form.get('password1')
        password2 = request.form.get('password2')

        user = User.query.filter_by(email=email).first()
        if user:
            flash('Email already exists.', category='error')
        elif len(email) < 4:
            flash('Email must be greater than 3 characters.', category='error')
        elif len(first_name) < 2:
            flash('First name must be greater than 1 character.', category='error')
        elif password1 != password2:
            flash('Passwords don\'t match.', category='error')
        elif len(password1) < 7:
            flash('Password must be at least 7 characters.', category='error')
        else:
            # Generate a unique PID
            pid = User.generate_pid()
            new_user = User(email=email, first_name=first_name, password=generate_password_hash(password1), pid=pid)
            db.session.add(new_user)
            db.session.commit()
            login_user(new_user, remember=True)
            flash('Account created! Your PID is: ' + pid, category='success')
            return redirect(url_for('views.home'))

    return render_template("sign_up.html")