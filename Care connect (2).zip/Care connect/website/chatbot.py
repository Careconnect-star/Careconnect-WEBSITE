from flask import jsonify, request
import os
from typing import Dict, Optional
import random
from datetime import datetime

class HealthInsuranceChatbot:
    def __init__(self):
        self.responses = {
            "greeting": {
                "text": "Hello! Welcome to Care Connect. How can I assist you with your health insurance needs today?",
                "buttons": [
                    {"text": "View Plans", "value": "plans"},
                    {"text": "File Claim", "value": "claims"},
                    {"text": "Renew Policy", "value": "renew"},
                    {"text": "Make Payment", "value": "payment"}
                ]
            },
            "plans": {
                "text": "We offer several health insurance plans:",
                "buttons": [
                    {"text": "Individual Plan (₹22/day)", "value": "individual"},
                    {"text": "Family Plan (32% discount)", "value": "family"},
                    {"text": "Senior Citizen Plan", "value": "senior"},
                    {"text": "Compare Plans", "value": "compare"}
                ]
            },
            "claims": {
                "text": "How would you like to proceed with your claim?",
                "buttons": [
                    {"text": "File New Claim", "value": "file_claim"},
                    {"text": "Check Status", "value": "claim_status"},
                    {"text": "Upload Documents", "value": "upload_docs"},
                    {"text": "Claim Guidelines", "value": "guidelines"}
                ]
            },
            "renew": {
                "text": "Policy renewal options:",
                "buttons": [
                    {"text": "Auto Renewal", "value": "auto_renew"},
                    {"text": "Manual Renewal", "value": "manual_renew"},
                    {"text": "Change Plan", "value": "change_plan"},
                    {"text": "View Benefits", "value": "benefits"}
                ]
            },
            "payment": {
                "text": "Choose your payment method:",
                "buttons": [
                    {"text": "Credit Card", "value": "credit_card"},
                    {"text": "Debit Card", "value": "debit_card"},
                    {"text": "Net Banking", "value": "net_banking"},
                    {"text": "UPI", "value": "upi"}
                ]
            },
            "individual": {
                "text": "Individual Health Plan features:\n- Cover for one person\n- Starting at ₹22/day\n- Cashless hospitalization\n- Pre & post hospitalization\n- Annual health check-up\nInterested in purchasing?",
                "buttons": [
                    {"text": "Yes, Buy Now", "value": "buy_individual"},
                    {"text": "View Details", "value": "individual_details"},
                    {"text": "Compare Plans", "value": "compare"},
                    {"text": "Back to Plans", "value": "plans"}
                ]
            },
            "family": {
                "text": "Family Health Plan benefits:\n- Cover for spouse & children\n- Up to 32% discount\n- Maternity benefits\n- Free health check-ups\n- Cashless hospitalization\nInterested in purchasing?",
                "buttons": [
                    {"text": "Yes, Buy Now", "value": "buy_family"},
                    {"text": "View Details", "value": "family_details"},
                    {"text": "Compare Plans", "value": "compare"},
                    {"text": "Back to Plans", "value": "plans"}
                ]
            },
            "senior": {
                "text": "Senior Citizen Plan features:\n- Special coverage for elders\n- Pre-existing disease cover\n- No medical tests required\n- Higher sum insured options\n- Emergency ambulance cover\nNeed more details?",
                "buttons": [
                    {"text": "Yes, Buy Now", "value": "buy_senior"},
                    {"text": "View Details", "value": "senior_details"},
                    {"text": "Compare Plans", "value": "compare"},
                    {"text": "Back to Plans", "value": "plans"}
                ]
            },
            "file_claim": {
                "text": "To file a claim:\n1. Log in to your account\n2. Go to Claims section\n3. Fill claim form\n4. Upload documents\n5. Submit for processing\nWould you like to proceed?",
                "buttons": [
                    {"text": "Yes, File Claim", "value": "proceed_claim"},
                    {"text": "View Documents Needed", "value": "claim_docs"},
                    {"text": "Back to Claims", "value": "claims"}
                ]
            },
            "claim_status": {
                "text": "To check claim status:\n1. Enter your claim ID\n2. View current status\n3. Track processing time\n4. Check payment details\nNeed your claim ID?",
                "buttons": [
                    {"text": "Check Status", "value": "check_status"},
                    {"text": "Back to Claims", "value": "claims"}
                ]
            },
            "auto_renew": {
                "text": "Auto Renewal benefits:\n- No manual intervention\n- Continuous coverage\n- No waiting period\n- Premium reminders\n- Easy payment options\nWant to enable auto-renewal?",
                "buttons": [
                    {"text": "Enable Auto Renewal", "value": "enable_auto_renew"},
                    {"text": "Back to Renewal", "value": "renew"}
                ]
            },
            "manual_renew": {
                "text": "Manual Renewal steps:\n1. Review current plan\n2. Check premium amount\n3. Choose payment method\n4. Complete renewal\nNeed help with renewal?",
                "buttons": [
                    {"text": "Start Renewal", "value": "start_renewal"},
                    {"text": "Back to Renewal", "value": "renew"}
                ]
            }
        }

    def get_response(self, message: str) -> Dict:
        message = message.lower().strip()
        if message in self.responses:
            return self.responses[message]
        for key, response in self.responses.items():
            if key in message:
                return response
        return {
            "text": "I'm not sure I understand. Please select one of the options below:",
            "buttons": [
                {"text": "View Plans", "value": "plans"},
                {"text": "File Claim", "value": "claims"},
                {"text": "Renew Policy", "value": "renew"},
                {"text": "Make Payment", "value": "payment"}
            ]
        }

def setup_chatbot_routes(app):
    chatbot = HealthInsuranceChatbot()
    
    @app.route('/api/chatbot/message', methods=['POST'])
    def chatbot_message():
        try:
            data = request.get_json()
            message = data.get('message', '')
            response = chatbot.get_response(message)
            return jsonify(response)
        except Exception as e:
            return jsonify({
                "text": "Sorry, something went wrong. Please try again.",
                "buttons": [
                    {"text": "Start Over", "value": "greeting"}
                ]
            }), 500