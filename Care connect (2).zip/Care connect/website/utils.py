from datetime import datetime, timedelta
from typing import Dict, List, Optional
import json

class InsuranceCalculator:
    @staticmethod
    def calculate_premium(age: int, plan_type: str, family_members: Optional[int] = None) -> float:
        base_premium = {
            'basic': 5000,
            'standard': 10000,
            'premium': 15000
        }.get(plan_type, 0)

        if age < 30:
            base_premium *= 0.8
        elif age > 50:
            base_premium *= 1.5

        if family_members and family_members > 1:
            discount = min(0.32, (family_members - 1) * 0.08)
            base_premium *= (1 - discount)

        return round(base_premium, 2)

    @staticmethod
    def calculate_waiting_period(start_date: datetime) -> Dict:
        end_date = start_date + timedelta(days=30)
        current_date = datetime.utcnow()
        
        days_remaining = (end_date - current_date).days
        progress = min(100, max(0, (30 - days_remaining) / 30 * 100))
        
        return {
            'days_remaining': max(0, days_remaining),
            'progress': round(progress, 2),
            'is_completed': days_remaining <= 0
        }

class FormValidator:
    @staticmethod
    def validate_claim_data(claim_data: Dict) -> Dict:
        required_fields = ['claim_type', 'amount', 'date', 'documents']
        missing_fields = [field for field in required_fields if field not in claim_data]
        
        if missing_fields:
            return {
                'valid': False,
                'message': f"Missing required fields: {', '.join(missing_fields)}"
            }
        
        try:
            amount = float(claim_data['amount'])
            if amount <= 0:
                return {
                    'valid': False,
                    'message': "Amount must be greater than 0"
                }
        except ValueError:
            return {
                'valid': False,
                'message': "Invalid amount format"
            }
        
        try:
            date = datetime.strptime(claim_data['date'], '%Y-%m-%d')
            if date > datetime.utcnow():
                return {
                    'valid': False,
                    'message': "Date cannot be in the future"
                }
        except ValueError:
            return {
                'valid': False,
                'message': "Invalid date format"
            }
        
        return {
            'valid': True,
            'message': "Claim data validated successfully"
        }

    @staticmethod
    def validate_renewal_data(renewal_data: Dict) -> Dict:
        required_fields = ['new_plan', 'renewal_date']
        missing_fields = [field for field in required_fields if field not in renewal_data]
        
        if missing_fields:
            return {
                'valid': False,
                'message': f"Missing required fields: {', '.join(missing_fields)}"
            }
        
        try:
            renewal_date = datetime.strptime(renewal_data['renewal_date'], '%Y-%m-%d')
            if renewal_date < datetime.utcnow():
                return {
                    'valid': False,
                    'message': "Renewal date cannot be in the past"
                }
        except ValueError:
            return {
                'valid': False,
                'message': "Invalid date format"
            }
        
        return {
            'valid': True,
            'message': "Renewal data validated successfully"
        }

class PlanRecommender:
    @staticmethod
    def get_recommendation(user_data: Dict) -> Dict:
        age = user_data.get('age', 0)
        family_size = user_data.get('family_size', 1)
        medical_history = user_data.get('medical_history', [])
        
        if family_size > 1:
            return {
                'recommended_plan': 'family',
                'reason': 'Family coverage needed',
                'estimated_premium': InsuranceCalculator.calculate_premium(age, 'standard', family_size)
            }
        elif age > 50:
            return {
                'recommended_plan': 'premium',
                'reason': 'Senior citizen coverage needed',
                'estimated_premium': InsuranceCalculator.calculate_premium(age, 'premium')
            }
        else:
            return {
                'recommended_plan': 'basic',
                'reason': 'Individual coverage suitable',
                'estimated_premium': InsuranceCalculator.calculate_premium(age, 'basic')
            }

class DataFormatter:
    @staticmethod
    def format_claim_data(claim: Dict) -> Dict:
        return {
            'id': claim.get('id'),
            'type': claim.get('claim_type'),
            'amount': f"₹{claim.get('amount', 0):,.2f}",
            'date': claim.get('date_of_service').strftime('%Y-%m-%d'),
            'status': claim.get('status', 'pending'),
            'description': claim.get('description', '')
        }

    @staticmethod
    def format_plan_data(plan: Dict) -> Dict:
        return {
            'type': plan.get('plan_type'),
            'start_date': plan.get('selection_date').strftime('%Y-%m-%d'),
            'end_date': plan.get('waiting_period_end').strftime('%Y-%m-%d'),
            'status': plan.get('plan_status'),
            'progress': plan.get('progress', 0)
        }

calculator = InsuranceCalculator()
validator = FormValidator()
recommender = PlanRecommender()
formatter = DataFormatter() 