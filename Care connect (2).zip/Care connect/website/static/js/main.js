// Import all JavaScript modules
import { init_chatbot } from './chatbot.js';
import { init_forms } from './forms.js';
import { init_ui } from './ui.js';

// Initialize all modules when the DOM is loaded
document.addEventListener('DOMContentLoaded', () => {
    // Initialize UI components
    init_ui();
    
    // Initialize forms
    init_forms();
    
    // Initialize chatbot
    init_chatbot();
    
    // Member selection functionality
    const memberOptions = document.querySelectorAll('.member-option');
    
    memberOptions.forEach(option => {
        option.addEventListener('click', function() {
            this.classList.toggle('selected');
            
            // Update discount message based on selections
            const selectedCount = document.querySelectorAll('.member-option.selected').length;
            const discountMsg = document.querySelector('.discount-note');
            
            if (selectedCount >= 2) {
                discountMsg.textContent = `You qualify for ₹25 off! (${selectedCount} members selected)`;
                discountMsg.style.color = 'green';
                discountMsg.style.fontWeight = 'bold';
            } else {
                discountMsg.textContent = 'Adding 2 or more members will give you up to ₹25 off';
                discountMsg.style.color = '';
                discountMsg.style.fontWeight = '';
            }
        });
    });
    
    // Smooth scrolling for anchor links
    document.querySelectorAll('a[href^="#"]').forEach(anchor => {
        anchor.addEventListener('click', function(e) {
            e.preventDefault();
            document.querySelector(this.getAttribute('href')).scrollIntoView({
                behavior: 'smooth'
            });
        });
    });
});