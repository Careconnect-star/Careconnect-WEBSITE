export function init_forms() {
    // Initialize all forms with validation
    const forms = document.querySelectorAll('form');
    forms.forEach(form => {
        form.addEventListener('submit', handleFormSubmit);
    });

    // Initialize file upload previews
    const fileInputs = document.querySelectorAll('input[type="file"]');
    fileInputs.forEach(input => {
        input.addEventListener('change', handleFileSelect);
    });

    // Initialize date inputs with validation
    const dateInputs = document.querySelectorAll('input[type="date"]');
    dateInputs.forEach(input => {
        input.addEventListener('change', validateDate);
    });
}

async function handleFormSubmit(event) {
    event.preventDefault();
    
    const form = event.target;
    const submitButton = form.querySelector('button[type="submit"]');
    const originalButtonText = submitButton.textContent;
    
    try {
        // Disable submit button and show loading state
        submitButton.disabled = true;
        submitButton.textContent = 'Processing...';
        
        // Get form data
        const formData = new FormData(form);
        
        // Send form data to server
        const response = await fetch(form.action, {
            method: form.method,
            body: formData
        });
        
        const result = await response.json();
        
        if (result.success) {
            // Show success message
            showNotification('success', result.message);
            // Redirect if specified
            if (result.redirect) {
                window.location.href = result.redirect;
            }
        } else {
            // Show error message
            showNotification('error', result.message);
        }
    } catch (error) {
        showNotification('error', 'An error occurred. Please try again.');
    } finally {
        // Reset submit button
        submitButton.disabled = false;
        submitButton.textContent = originalButtonText;
    }
}

function handleFileSelect(event) {
    const input = event.target;
    const preview = document.querySelector(`#${input.id}-preview`);
    const file = input.files[0];
    
    if (file) {
        // Validate file size
        if (file.size > 16 * 1024 * 1024) { // 16MB limit
            showNotification('error', 'File size must be less than 16MB');
            input.value = '';
            return;
        }
        
        // Validate file type
        const allowedTypes = ['application/pdf', 'image/jpeg', 'image/png'];
        if (!allowedTypes.includes(file.type)) {
            showNotification('error', 'Invalid file type. Please upload a PDF or image file.');
            input.value = '';
            return;
        }
        
        // Show preview
        if (preview) {
            if (file.type.startsWith('image/')) {
                const reader = new FileReader();
                reader.onload = function(e) {
                    preview.src = e.target.result;
                    preview.style.display = 'block';
                };
                reader.readAsDataURL(file);
            } else {
                preview.textContent = file.name;
                preview.style.display = 'block';
            }
        }
    } else {
        if (preview) {
            preview.style.display = 'none';
        }
    }
}

function validateDate(event) {
    const input = event.target;
    const selectedDate = new Date(input.value);
    const today = new Date();
    
    // Remove time part for comparison
    selectedDate.setHours(0, 0, 0, 0);
    today.setHours(0, 0, 0, 0);
    
    if (input.hasAttribute('data-future-only') && selectedDate <= today) {
        showNotification('error', 'Please select a future date');
        input.value = '';
    } else if (input.hasAttribute('data-past-only') && selectedDate >= today) {
        showNotification('error', 'Please select a past date');
        input.value = '';
    }
}

function showNotification(type, message) {
    const notification = document.createElement('div');
    notification.className = `notification ${type}`;
    notification.textContent = message;
    
    document.body.appendChild(notification);
    
    // Remove notification after 3 seconds
    setTimeout(() => {
        notification.remove();
    }, 3000);
} 