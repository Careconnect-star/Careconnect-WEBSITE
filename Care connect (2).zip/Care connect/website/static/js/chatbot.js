document.addEventListener('DOMContentLoaded', function() {
    const chatButton = document.getElementById('chat-button');
    const chatContainer = document.getElementById('chat-container');
    const chatClose = document.getElementById('chat-close');
    const chatMessages = document.getElementById('chat-messages');
    const chatInput = document.getElementById('chat-input');
    const chatSend = document.getElementById('chat-send');
    const chatNotification = document.getElementById('chat-notification');
    const chatOptions = document.querySelectorAll('.chat-option-btn');

    let unreadMessages = 0;
    let isChatOpen = false;
    let typingIndicator = null;

    // Initialize chat with welcome message
    function initializeChat() {
        addBotMessage("Hello! Welcome to Care Connect. How can I assist you with your health insurance needs today?");
        addBotButtons([
            {"text": "View Plans", "value": "plans"},
            {"text": "File Claim", "value": "claims"},
            {"text": "Renew Policy", "value": "renew"},
            {"text": "Make Payment", "value": "payment"}
        ]);
    }

    // Toggle chat visibility
    function toggleChat() {
        isChatOpen = !isChatOpen;
        if (isChatOpen) {
            chatContainer.style.display = 'flex';
            chatContainer.classList.add('active');
            unreadMessages = 0;
            updateNotification();
            chatInput.focus();
        } else {
            chatContainer.style.display = 'none';
            chatContainer.classList.remove('active');
        }
    }

    // Event Listeners
    chatButton.addEventListener('click', toggleChat);
    chatClose.addEventListener('click', toggleChat);

    // Handle send button click
    chatSend.addEventListener('click', sendMessage);

    // Handle enter key press
    chatInput.addEventListener('keypress', function(e) {
        if (e.key === 'Enter') {
            sendMessage();
        }
    });

    // Handle quick option buttons
    chatOptions.forEach(option => {
        option.addEventListener('click', function() {
            const optionValue = this.getAttribute('data-option');
            handleQuickOption(optionValue);
        });
    });

    async function sendMessage() {
        const message = chatInput.value.trim();
        if (message) {
            addUserMessage(message);
            chatInput.value = '';
            
            // Show typing indicator
            typingIndicator = showTypingIndicator();
            
            try {
                const response = await fetch('/api/chatbot/message', {
                    method: 'POST',
                    headers: {
                        'Content-Type': 'application/json'
                    },
                    body: JSON.stringify({ message: message })
                });
                
                const data = await response.json();
                
                // Remove typing indicator
                removeTypingIndicator(typingIndicator);
                
                // Display bot response
                if (data.text) {
                    addBotMessage(data.text);
                    if (data.buttons && data.buttons.length > 0) {
                        addBotButtons(data.buttons);
                    }
                } else {
                    addBotMessage("I'm sorry, I encountered an error. Please try again.");
                }
            } catch (error) {
                removeTypingIndicator(typingIndicator);
                addBotMessage("I'm sorry, I'm having trouble connecting right now. Please try again later.");
            }
        }
    }

    async function handleQuickOption(optionValue) {
        addUserMessage(optionValue);
        typingIndicator = showTypingIndicator();
        
        try {
            const response = await fetch('/api/chatbot/message', {
                method: 'POST',
                headers: {
                    'Content-Type': 'application/json'
                },
                body: JSON.stringify({ message: optionValue })
            });
            
            const data = await response.json();
            removeTypingIndicator(typingIndicator);
            
            if (data.text) {
                addBotMessage(data.text);
                if (data.buttons && data.buttons.length > 0) {
                    addBotButtons(data.buttons);
                }
            } else {
                addBotMessage("I'm sorry, I encountered an error. Please try again.");
            }
        } catch (error) {
            removeTypingIndicator(typingIndicator);
            addBotMessage("I'm sorry, I'm having trouble connecting right now. Please try again later.");
        }
    }

    function addUserMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message user-message';
        messageElement.textContent = message;
        chatMessages.appendChild(messageElement);
        scrollToBottom();
    }

    function addBotMessage(message) {
        const messageElement = document.createElement('div');
        messageElement.className = 'message bot-message';
        messageElement.textContent = message;
        chatMessages.appendChild(messageElement);
        scrollToBottom();
        
        if (!isChatOpen) {
            unreadMessages++;
            updateNotification();
        }
    }

    function addBotButtons(buttons) {
        const buttonContainer = document.createElement('div');
        buttonContainer.className = 'chat-buttons';
        
        buttons.forEach(button => {
            const buttonElement = document.createElement('button');
            buttonElement.className = 'chat-button-option';
            buttonElement.textContent = button.text;
            buttonElement.addEventListener('click', () => {
                addUserMessage(button.text);
                handleQuickOption(button.value);
            });
            buttonContainer.appendChild(buttonElement);
        });
        
        chatMessages.appendChild(buttonContainer);
        scrollToBottom();
    }

    function scrollToBottom() {
        chatMessages.scrollTop = chatMessages.scrollHeight;
    }

    function updateNotification() {
        chatNotification.textContent = unreadMessages;
        chatNotification.style.display = unreadMessages > 0 ? 'block' : 'none';
    }

    function showTypingIndicator() {
        const indicator = document.createElement('div');
        indicator.className = 'message bot-message typing-indicator';
        indicator.innerHTML = '<span></span><span></span><span></span>';
        chatMessages.appendChild(indicator);
        scrollToBottom();
        return indicator;
    }

    function removeTypingIndicator(indicator) {
        if (indicator && indicator.parentNode) {
            indicator.parentNode.removeChild(indicator);
        }
    }

    // Initialize the chat
    initializeChat();
});