from PIL import Image, ImageDraw
import os

def create_heart_icon(size):
    # Create a new image with a transparent background
    img = Image.new('RGBA', (size, size), (0, 0, 0, 0))
    draw = ImageDraw.Draw(img)
    
    # Calculate heart dimensions
    heart_width = size * 0.8
    heart_height = size * 0.7
    x_offset = (size - heart_width) / 2
    y_offset = (size - heart_height) / 2 + size * 0.1
    
    # Draw heart shape using a polygon
    heart_shape = [
        (x_offset + heart_width/2, y_offset + heart_height),  # Bottom point
        (x_offset, y_offset + heart_height/3),  # Left control point
        (x_offset + heart_width/2, y_offset),  # Top middle point
        (x_offset + heart_width, y_offset + heart_height/3),  # Right control point
        (x_offset + heart_width/2, y_offset + heart_height),  # Back to bottom point
    ]
    
    # Draw filled heart
    draw.polygon(heart_shape, fill=(38, 74, 159, 255))
    
    return img

def main():
    # Create output directory if it doesn't exist
    os.makedirs(os.path.dirname(os.path.abspath(__file__)), exist_ok=True)
    
    # Generate 32x32 PNG
    img_32 = create_heart_icon(32)
    img_32.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'favicon-32x32.png'))
    
    # Generate 16x16 PNG
    img_16 = create_heart_icon(16)
    img_16.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'favicon-16x16.png'))
    
    # Generate ICO file
    img_32.save(os.path.join(os.path.dirname(os.path.abspath(__file__)), 'favicon.ico'), 
                format='ICO', sizes=[(32, 32)])
    
    print("Favicon files generated successfully!")

if __name__ == "__main__":
    main() 