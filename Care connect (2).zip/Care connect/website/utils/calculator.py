from datetime import datetime, timedelta
from typing import Dict
from flask import current_app

class InsuranceCalculator:
    @staticmethod
    def calculate_premium(age: int, plan_type: str, family_members: int = None) -> float:
        """Calculate insurance premium based on various factors"""
        plan_config = current_app.config['INSURANCE_PLANS'].get(plan_type)
        if not plan_config:
            return 0
            
        base_premium = plan_config['base_price']

        # Age-based adjustments
        if age < 30:
            base_premium *= 0.8
        elif age > 50:
            base_premium *= 1.5

        # Family discount
        if family_members and family_members > 1:
            discount = min(
                current_app.config['MAX_FAMILY_DISCOUNT'],
                (family_members - 1) * current_app.config['FAMILY_DISCOUNT_RATE']
            )
            base_premium *= (1 - discount)

        return round(base_premium, 2)

    @staticmethod
    def calculate_waiting_period(start_date: datetime) -> Dict:
        """Calculate waiting period details"""
        waiting_days = current_app.config['WAITING_PERIOD_DAYS']
        end_date = start_date + timedelta(days=waiting_days)
        current_date = datetime.utcnow()
        
        days_remaining = (end_date - current_date).days
        progress = min(100, max(0, (waiting_days - days_remaining) / waiting_days * 100))
        
        return {
            'days_remaining': max(0, days_remaining),
            'progress': round(progress, 2),
            'is_completed': days_remaining <= 0
        } 