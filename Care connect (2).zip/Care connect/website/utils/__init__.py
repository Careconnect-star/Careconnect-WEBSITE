from .calculator import InsuranceCalculator
from .validator import FormValidator
from .recommender import PlanRecommender
from .formatter import DataFormatter

# Create instances
calculator = InsuranceCalculator()
validator = FormValidator()
recommender = PlanRecommender()
formatter = DataFormatter()

__all__ = ['calculator', 'validator', 'recommender', 'formatter'] 