from typing import Dict
from datetime import datetime

class DataFormatter:
    @staticmethod
    def format_claim_data(claim: Dict) -> Dict:
        """Format claim data for display"""
        return {
            'id': claim.get('id'),
            'type': claim.get('claim_type'),
            'amount': f"₹{claim.get('amount', 0):,.2f}",
            'date': claim.get('date_of_service').strftime('%Y-%m-%d') if isinstance(claim.get('date_of_service'), datetime) else claim.get('date_of_service'),
            'status': claim.get('status', 'pending'),
            'description': claim.get('description', ''),
            'documents': claim.get('documents')
        }

    @staticmethod
    def format_plan_data(plan: Dict) -> Dict:
        """Format plan data for display"""
        return {
            'type': plan.get('plan_type'),
            'start_date': plan.get('selection_date').strftime('%Y-%m-%d') if isinstance(plan.get('selection_date'), datetime) else plan.get('selection_date'),
            'end_date': plan.get('waiting_period_end').strftime('%Y-%m-%d') if isinstance(plan.get('waiting_period_end'), datetime) else plan.get('waiting_period_end'),
            'status': plan.get('plan_status'),
            'progress': plan.get('progress', 0),
            'health_checkup_status': plan.get('health_checkup_status'),
            'health_checkup_file': plan.get('health_checkup_file')
        }

    @staticmethod
    def format_renewal_data(renewal: Dict) -> Dict:
        """Format renewal data for display"""
        return {
            'current_plan': renewal.get('current_plan'),
            'new_plan': renewal.get('new_plan'),
            'renewal_date': renewal.get('renewal_date').strftime('%Y-%m-%d') if isinstance(renewal.get('renewal_date'), datetime) else renewal.get('renewal_date'),
            'status': renewal.get('status', 'pending'),
            'health_checkup_status': renewal.get('health_checkup_status'),
            'health_checkup_file': renewal.get('health_checkup_file')
        }

    @staticmethod
    def format_user_data(user: Dict) -> Dict:
        """Format user data for display"""
        return {
            'name': user.get('name'),
            'email': user.get('email'),
            'age': user.get('age'),
            'plan': user.get('plan'),
            'family_members': user.get('family_members', '').split(',') if user.get('family_members') else [],
            'payment_status': user.get('payment_status'),
            'payment_date': user.get('payment_date').strftime('%Y-%m-%d') if isinstance(user.get('payment_date'), datetime) else user.get('payment_date')
        } 