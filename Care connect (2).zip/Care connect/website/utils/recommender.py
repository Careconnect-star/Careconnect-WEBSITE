from typing import Dict
from flask import current_app
from .calculator import InsuranceCalculator

class PlanRecommender:
    @staticmethod
    def get_recommendation(user_data: Dict) -> Dict:
        """Get personalized plan recommendation based on user data"""
        age = user_data.get('age', 0)
        family_size = user_data.get('family_size', 1)
        medical_history = user_data.get('medical_history', [])
        
        # Get plan configurations
        plans = current_app.config['INSURANCE_PLANS']
        
        # Basic recommendation logic
        if family_size > 1:
            return {
                'recommended_plan': 'standard',
                'reason': f'Based on your family size of {family_size}, we recommend our Standard Plan which provides comprehensive coverage for your entire family.',
                'estimated_premium': InsuranceCalculator.calculate_premium(age, 'standard', family_size),
                'plan_details': plans['standard']
            }
        elif age > 50:
            return {
                'recommended_plan': 'premium',
                'reason': 'Given your age, we recommend our Premium Plan which offers enhanced coverage and additional benefits suitable for senior citizens.',
                'estimated_premium': InsuranceCalculator.calculate_premium(age, 'premium'),
                'plan_details': plans['premium']
            }
        else:
            return {
                'recommended_plan': 'basic',
                'reason': 'Our Basic Plan provides essential coverage at an affordable price, suitable for individual policyholders.',
                'estimated_premium': InsuranceCalculator.calculate_premium(age, 'basic'),
                'plan_details': plans['basic']
            }

    @staticmethod
    def get_plan_comparison() -> Dict:
        """Get comparison of all available plans"""
        plans = current_app.config['INSURANCE_PLANS']
        return {
            'plans': plans,
            'comparison_points': [
                'coverage',
                'features',
                'base_price'
            ]
        } 