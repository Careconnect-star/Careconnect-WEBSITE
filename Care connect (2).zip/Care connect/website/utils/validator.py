from datetime import datetime
from typing import Dict
from flask import current_app

class FormValidator:
    @staticmethod
    def validate_claim_data(claim_data: Dict) -> Dict:
        """Validate claim data and return appropriate response"""
        required_fields = ['claim_type', 'amount', 'date', 'documents']
        missing_fields = [field for field in required_fields if field not in claim_data]
        
        if missing_fields:
            return {
                'valid': False,
                'message': f"Missing required fields: {', '.join(missing_fields)}"
            }
        
        # Validate amount
        try:
            amount = float(claim_data['amount'])
            if amount <= 0:
                return {
                    'valid': False,
                    'message': "Amount must be greater than 0"
                }
        except ValueError:
            return {
                'valid': False,
                'message': "Invalid amount format"
            }
        
        # Validate date
        try:
            date = datetime.strptime(claim_data['date'], '%Y-%m-%d')
            if date > datetime.utcnow():
                return {
                    'valid': False,
                    'message': "Date cannot be in the future"
                }
        except ValueError:
            return {
                'valid': False,
                'message': "Invalid date format"
            }
        
        # Validate file if provided
        if claim_data['documents']:
            file = claim_data['documents']
            if not FormValidator.allowed_file(file.filename):
                return {
                    'valid': False,
                    'message': f"Invalid file type. Allowed types: {', '.join(current_app.config['ALLOWED_EXTENSIONS'])}"
                }
        
        return {
            'valid': True,
            'message': "Claim data validated successfully"
        }

    @staticmethod
    def validate_renewal_data(renewal_data: Dict) -> Dict:
        """Validate renewal data and return appropriate response"""
        required_fields = ['new_plan', 'renewal_date']
        missing_fields = [field for field in required_fields if field not in renewal_data]
        
        if missing_fields:
            return {
                'valid': False,
                'message': f"Missing required fields: {', '.join(missing_fields)}"
            }
        
        # Validate plan type
        if renewal_data['new_plan'] not in current_app.config['INSURANCE_PLANS']:
            return {
                'valid': False,
                'message': "Invalid plan type selected"
            }
        
        # Validate renewal date
        try:
            renewal_date = datetime.strptime(renewal_data['renewal_date'], '%Y-%m-%d')
            if renewal_date < datetime.utcnow():
                return {
                    'valid': False,
                    'message': "Renewal date cannot be in the past"
                }
        except ValueError:
            return {
                'valid': False,
                'message': "Invalid date format"
            }
        
        return {
            'valid': True,
            'message': "Renewal data validated successfully"
        }

    @staticmethod
    def allowed_file(filename: str) -> bool:
        """Check if the file extension is allowed"""
        return '.' in filename and \
               filename.rsplit('.', 1)[1].lower() in current_app.config['ALLOWED_EXTENSIONS'] 