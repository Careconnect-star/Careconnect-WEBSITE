from website import db
from flask_login import UserMixin
from datetime import datetime
import random
import string

class User(db.Model, UserMixin):
    id = db.Column(db.Integer, primary_key=True)
    email = db.Column(db.String(150), unique=True)
    password = db.Column(db.String(150))
    first_name = db.Column(db.String(150))
    pid = db.Column(db.String(4), unique=True)
    plan = db.Column(db.String(50))
    needs_password_change = db.Column(db.Boolean, default=False)
    role = db.Column(db.String(20), default='customer')  # 'customer' or 'agent'

    @staticmethod
    def generate_pid():
        while True:
            # Generate a 4-character PID with letters and numbers
            pid = ''.join(random.choices(string.ascii_uppercase + string.digits, k=4))
            # Check if PID already exists
            if not User.query.filter_by(pid=pid).first():
                return pid

class TempPlan(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    plan_type = db.Column(db.String(50), nullable=False)  # bronze, silver, gold, diamond
    selection_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    waiting_period_end = db.Column(db.DateTime, nullable=False)
    health_checkup_status = db.Column(db.String(20), default='pending')  # pending, submitted, approved, rejected
    health_checkup_file = db.Column(db.String(255))  # Path to uploaded file
    plan_status = db.Column(db.String(20), default='waiting')  # waiting, submitted, active, rejected
    progress_percentage = db.Column(db.Integer, default=0)

    def calculate_progress(self):
        if self.plan_status == 'waiting':
            total_days = (self.waiting_period_end - self.selection_date).days
            days_passed = (datetime.utcnow() - self.selection_date).days
            self.progress_percentage = min(int((days_passed / total_days) * 100), 100)
        elif self.plan_status == 'submitted':
            self.progress_percentage = 100
        elif self.plan_status == 'active':
            self.progress_percentage = 100
        elif self.plan_status == 'rejected':
            self.progress_percentage = 0
        return self.progress_percentage

    def is_waiting_period_over(self):
        return datetime.utcnow() >= self.waiting_period_end

    def get_status_message(self):
        if not self.plan_type:
            return "No plan selected yet"
        elif self.plan_status == 'waiting':
            return f"Waiting period for {self.plan_type.capitalize()} plan"
        elif self.plan_status == 'submitted':
            return "Health checkup submitted for review"
        elif self.plan_status == 'active':
            return f"{self.plan_type.capitalize()} plan is active"
        elif self.plan_status == 'rejected':
            return "Plan application rejected"
        return "Unknown status"

class Claim(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    claim_type = db.Column(db.String(50), nullable=False)  # medical, dental, vision, etc.
    amount = db.Column(db.Float, nullable=False)
    description = db.Column(db.Text, nullable=False)
    date_of_service = db.Column(db.Date, nullable=False)
    submission_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    documents = db.Column(db.String(255))  # Path to uploaded documents
    notes = db.Column(db.Text)  # For internal notes or rejection reasons

    def get_status_message(self):
        if self.status == 'pending':
            return "Your claim is being reviewed"
        elif self.status == 'approved':
            return "Your claim has been approved"
        elif self.status == 'rejected':
            return "Your claim has been rejected"
        return "Unknown status"

class PlanRenewal(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    user_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    current_plan = db.Column(db.String(50), nullable=False)
    new_plan = db.Column(db.String(50), nullable=False)
    renewal_date = db.Column(db.DateTime, nullable=False)
    submission_date = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    status = db.Column(db.String(20), default='pending')  # pending, approved, rejected
    health_checkup_status = db.Column(db.String(20), default='pending')  # pending, submitted, approved, rejected
    health_checkup_file = db.Column(db.String(255))  # Path to uploaded file
    notes = db.Column(db.Text)  # For internal notes or rejection reasons

    def get_status_message(self):
        if self.status == 'pending':
            return "Your renewal request is being reviewed"
        elif self.status == 'approved':
            return "Your plan renewal has been approved"
        elif self.status == 'rejected':
            return "Your plan renewal has been rejected"
        return "Unknown status"

class ChatMessage(db.Model):
    id = db.Column(db.Integer, primary_key=True)
    sender_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=False)
    receiver_id = db.Column(db.Integer, db.ForeignKey('user.id'), nullable=True)  # For customer-to-agent messages
    content = db.Column(db.Text, nullable=False)
    timestamp = db.Column(db.DateTime, nullable=False, default=datetime.utcnow)
    is_read = db.Column(db.Boolean, default=False)
    chat_session = db.Column(db.String(50), nullable=False)  # To group messages in a session